#include <Arduino.h>
#include "Simple_Esp32WiFiManager.h"

void setup() {
  Serial.begin(115200);
  startWiFiManager();   // 🔹 se encarga de todo el manejo WiFi
}

void loop() {
  // Acá tu lógica principal, ya con WiFi funcionando
    if (WiFi.status() == WL_CONNECTED)
   {   
    Serial.print("Conectado !!!");
    delay(2000);

    //Pon aqui Tu codigo ya que Estas conectado a WIFI...
    //

   } 
  else
   {
    Serial.println("⚠️ No hay conexión WiFi...");
    delay(2000);
   }
}
